﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefabInstaller
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
